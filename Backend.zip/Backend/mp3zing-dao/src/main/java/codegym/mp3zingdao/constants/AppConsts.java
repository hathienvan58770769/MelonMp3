package codegym.mp3zingdao.constants;

public interface AppConsts {
    final static String STRING_TO_DATE_FORMAT = "yyyy-MM-dd";
}
