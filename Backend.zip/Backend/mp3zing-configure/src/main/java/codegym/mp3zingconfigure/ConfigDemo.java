package codegym.mp3zingconfigure;

public class ConfigDemo {
}
