import { Component, OnInit, OnDestroy } from '@angular/core';
import { Song } from 'src/app/models/song.class';
import { StreamState } from 'src/app/models/stream-state.interface';
import { MusicService } from 'src/app/services/music.service';
import { SongService } from 'src/app/services/song.service';
import { Subscription } from 'rxjs';
import { ActivatedRoute, Router, Params } from '@angular/router';

@Component({
  selector: 'app-music-player',
  templateUrl: './music-player.component.html',
  styleUrls: ['./music-player.component.css']
})
export class MusicPlayerComponent implements OnInit, OnDestroy{
  public songs :Song[];
  public state: StreamState;
  public currentFile: any = {};
  public subscription: Subscription;
  public subscriptionSong: Subscription;
  constructor(
    public musicService: MusicService, 
    public songService: SongService, 
    public routerActivatedService: ActivatedRoute,
    public routerService: Router
  ) {    
  }
  ngOnInit(){
this.subscription =  this.songService.getAllSongs().subscribe(data => {
  this.songs = data;
});

this.subscriptionSong = this.musicService.getState().subscribe(data=>{
  this.state = data;
})
  }
  ngOnDestroy(){
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
    if (this.subscriptionSong) {
      this.subscriptionSong.unsubscribe();
    }
  }
  playStream(fileMp3){
    this.musicService.playStream(fileMp3).subscribe(data => {

    })
  }
  openFile(song, index){
    this.currentFile = {index, song};
    this.musicService.stop();
    this.playStream(song.fileMp3);
  }
  pause(){
    this.musicService.pause();
  }
  play(){
    this.musicService.play();
  }
  stop(){
    this.musicService.stop();
  }
  next(){
    const index = this.currentFile.index + 1;
    const song = this.songs[index];
    this.openFile(song, index);
  }
  previous(){
    const index = this.currentFile.index - 1;
    const song = this.songs[index];
    this.openFile(song, index);
  }
  isFirstPlaying(){
    return this.currentFile.index === 0;
  }
  isLastPlaying() {
    return this.currentFile.index === this.songs.length - 1;
  }
  onSliderChangeEnd(change) {
    this.musicService.seekTo(change.value);
  }
  
}
