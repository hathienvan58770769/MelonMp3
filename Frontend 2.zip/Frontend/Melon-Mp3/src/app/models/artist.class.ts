
export class Artist{
    id?:Number;
    name?: String;
    avatar?:String;
    country?:String;
    
}