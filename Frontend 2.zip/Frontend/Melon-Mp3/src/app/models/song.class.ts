export class Song {
    id?: Number;
    nameSong: String;
    descriptionSong: String;
    fileMp3?: String;
    avatarSong: String;
    comment: String;

}